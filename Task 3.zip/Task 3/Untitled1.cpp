#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <stdexcept>  // For runtime_error
#include <sstream>    // For stringstream

using namespace std;

string readFile(const string &filePath) {
    ifstream file(filePath.c_str(), ios::binary);  // Use c_str() for file path
    if (!file) {
        throw runtime_error("Could not open file for reading.");
    }

    string content((istreambuf_iterator<char>(file)), istreambuf_iterator<char>());
    return content;
}

void writeFile(const string &filePath, const string &data) {
    ofstream file(filePath.c_str(), ios::binary);  // Use c_str() for file path
    if (!file) {
        throw runtime_error("Could not open file for writing.");
    }

    file.write(data.c_str(), data.size());
}

string intToString(int number) {
    ostringstream oss;
    oss << number;
    return oss.str();
}

int stringToInt(const string &str) {
    istringstream iss(str);
    int number;
    iss >> number;
    return number;
}

string compress(const string &data) {
    string compressed;
    int n = data.size();

    for (int i = 0; i < n; i++) {
        int count = 1;
        while (i < n - 1 && data[i] == data[i + 1]) {
            count++;
            i++;
        }
        compressed += data[i];
        compressed += intToString(count);
    }

    return compressed;
}

string decompress(const string &data) {
    string decompressed;
    int n = data.size();

    for (int i = 0; i < n; i++) {
        char ch = data[i];
        string countStr;
        while (i + 1 < n && isdigit(data[i + 1])) {
            countStr += data[++i];
        }
        int count = stringToInt(countStr);
        decompressed.append(count, ch);
    }

    return decompressed;
}

int main() {
    try {
        string inputFilePath = "input.txt";
        string compressedFilePath = "compressed.txt";
        string decompressedFilePath = "decompressed.txt";

        string inputData = readFile(inputFilePath);

        string compressedData = compress(inputData);
        writeFile(compressedFilePath, compressedData);

        string decompressedData = decompress(compressedData);
        writeFile(decompressedFilePath, decompressedData);

        cout << "Compression and decompression completed successfully." << endl;
    } catch (const exception &ex) {
        cerr << "Error: " << ex.what() << endl;
    }

    return 0;
}

